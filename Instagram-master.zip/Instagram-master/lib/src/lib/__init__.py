# Date: 05/10/2018
# Author: Pure-L0G1C
# Description: init file